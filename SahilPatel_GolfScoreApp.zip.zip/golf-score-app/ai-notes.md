# AI Notes

**Tools used:** ChatGPT (GPT-5 Thinking).

**Key prompts:** Asked ChatGPT to generate a minimal, mobile-first golf scorekeeping app with:
- 9/18 holes toggle, 1–4 players
- numeric keypad entries
- running totals
- undo / clear last / reset
- localStorage persistence
- screen wake lock

**Accepted vs edited:** Accepted most generated structure; edited styles for clarity, added robust state resize for holes/players and undo stack cap, and improved wake lock handling.

**Verification & Pitfalls:**
- Manually tested in desktop and mobile simulator:
  - Changing holes & player count resizes grid while preserving prior data where possible.
  - Inputs accept only non-negative integers; empty = no stroke yet.
  - Totals update live on every edit.
  - Undo reverts last change; Clear Last removes the most recent non-empty cell.
  - Full Reset clears scores and restores default names.
  - LocalStorage works across reloads.
- Pitfalls: Wake Lock may be unsupported; app warns user. No service worker (optional).

